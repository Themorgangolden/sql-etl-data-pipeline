# SQL Data Pipeline Project

This project demonstrates an ETL pipeline using Python, Airflow, and SQL Server.